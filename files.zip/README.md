# 🎮 GameDeal — Kurulum & Deploy Rehberi

Oyun indirim takip uygulamanı yayına almak için adım adım rehber.
**Toplam maliyet: ₺0** (başlangıç için)

---

## 📁 Dosyalar

| Dosya | Açıklama |
|---|---|
| `gamedeals-final.html` | Ana uygulama (tüm frontend) |
| `supabase-setup.sql` | Veritabanı tabloları |
| `notify-users.ts` | Haftalık e-posta bildirimi |
| `README.md` | Bu dosya |

---

## 🚀 ADIM 1 — GitHub'a Yükle

1. [github.com](https://github.com) adresine git, ücretsiz hesap oluştur
2. "New repository" → repo adı: `gamedeal` → Create
3. Tüm dosyaları repo'ya yükle (drag & drop çalışır)

---

## 🌐 ADIM 2 — Vercel ile Yayına Al (Ücretsiz)

1. [vercel.com](https://vercel.com) adresine git, GitHub ile giriş yap
2. "Add New Project" → GitHub repo'nu seç → Import
3. Framework: **Other** seç
4. Deploy et → Otomatik URL alırsın (örn: `gamedeal.vercel.app`)

**Her GitHub push'unda otomatik güncellenir!**

---

## 🗄️ ADIM 3 — Supabase Kurulumu (Ücretsiz)

1. [supabase.com](https://supabase.com) adresine git, ücretsiz hesap aç
2. "New Project" → proje adı: `gamedeal` → şifre belirle → Create
3. Sol menü → **SQL Editor** → New Query
4. `supabase-setup.sql` dosyasının içeriğini yapıştır → **Run**
5. Sol menü → **Settings** → **API**:
   - `Project URL` → kopyala
   - `anon public` key → kopyala

6. `gamedeals-final.html` dosyasında şu satırları güncelle:
```javascript
const SUPA_URL = 'https://SENIN-PROJE-ID.supabase.co';
const SUPA_KEY = 'SENIN-ANON-KEY';
```

7. `notify-users.ts` bölümündeki yorumu (`/* ... */`) kaldır

---

## 📧 ADIM 4 — Resend E-posta Kurulumu (Ücretsiz)

1. [resend.com](https://resend.com) adresine git, ücretsiz hesap aç
   - Günde 100 e-posta, ayda 3000 e-posta ücretsiz
2. API Keys → Create API Key → kopyala
3. Domains → Add Domain → alan adını doğrula (domain almışsan)
   - Domain yoksa `onboarding@resend.dev` adresini kullanabilirsin (test için)

---

## ⚡ ADIM 5 — Edge Function Deploy

1. Supabase Dashboard → **Edge Functions** → New Function
2. Fonksiyon adı: `notify-users`
3. `notify-users.ts` dosyasının içeriğini yapıştır
4. Deploy et
5. **Edge Functions → notify-users → Secrets** bölümüne ekle:
   ```
   RESEND_API_KEY = resend'den aldığın key
   SITE_URL = https://gamedeal.vercel.app
   FROM_EMAIL = onboarding@resend.dev
   ```

---

## ⏰ ADIM 6 — Otomatik Bildirim (Her Perşembe)

Supabase Dashboard → **Database** → **Scheduled Jobs** → New Job:
```
Name:     weekly-notifier
Schedule: 0 15 * * 4    (Her Perşembe 15:00 UTC = 18:00 Türkiye)
Function: notify-users
```

---

## 💰 ADIM 7 — Para Kazanma

### Affiliate Linkleri Aktif Et
1. [epicgames.com/affiliate](https://www.epicgames.com/affiliate) → Başvur (ücretsiz)
2. [steampowered.com/affilate](https://www.steampowered.com/affilate) → Başvur
3. [cheapshark.com](https://www.cheapshark.com) linklerini kullan (otomatik affiliate)

### Reklam Ekle (Kullanıcı büyüyünce)
1. [Google AdSense](https://adsense.google.com) → Başvur
2. Onay gelince kodu HTML'e yapıştır

---

## 📊 Tahmini Gelir (İlk 6 Ay)

| Kullanıcı | Reklam Geliri | Affiliate | Toplam |
|---|---|---|---|
| 100 | $5/ay | $10/ay | $15/ay |
| 1.000 | $50/ay | $100/ay | $150/ay |
| 10.000 | $500/ay | $1.000/ay | $1.500/ay |
| 100.000 | $5.000/ay | $10.000/ay | $15.000/ay |

---

## 🔧 Sonraki Özellikler (Yol Haritası)

- [ ] iOS & Android uygulaması (React Native)
- [ ] Push notification (PWA ile ücretsiz)
- [ ] Fiyat geçmişi grafiği
- [ ] Kullanıcı yorumları
- [ ] GOG ve Xbox API entegrasyonu
- [ ] Türkçe oyun kategorileri
- [ ] Discord botu

---

## 📞 Yardım

Herhangi bir adımda takılırsan Claude'a sor!
