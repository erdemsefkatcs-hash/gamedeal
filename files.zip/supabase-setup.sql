-- ================================================================
-- GAMEDEAL — SUPABASE KURULUM SQL
-- Supabase Dashboard → SQL Editor → Bu dosyayı yapıştır → Run
-- ================================================================

-- 1. ABONELİK TABLOSU
CREATE TABLE IF NOT EXISTS subscribers (
  id             UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  email          TEXT        UNIQUE NOT NULL,
  notif_free     BOOLEAN     DEFAULT true,
  notif_deals    BOOLEAN     DEFAULT true,
  notif_wishlist BOOLEAN     DEFAULT false,
  confirmed      BOOLEAN     DEFAULT true,
  created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- 2. İSTEK LİSTESİ
CREATE TABLE IF NOT EXISTS wishlists (
  id         UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  email      TEXT        NOT NULL,
  game_title TEXT        NOT NULL,
  platform   TEXT,
  added_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(email, game_title)
);

-- 3. BİLDİRİM LOGU
CREATE TABLE IF NOT EXISTS notif_log (
  id         UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  email      TEXT        NOT NULL,
  type       TEXT        NOT NULL,
  game_title TEXT,
  sent_at    TIMESTAMPTZ DEFAULT NOW()
);

-- 4. GÜVENLİK (RLS)
ALTER TABLE subscribers ENABLE ROW LEVEL SECURITY;
ALTER TABLE wishlists   ENABLE ROW LEVEL SECURITY;

CREATE POLICY "insert_subscriber" ON subscribers FOR INSERT WITH CHECK (true);
CREATE POLICY "insert_wishlist"   ON wishlists   FOR INSERT WITH CHECK (true);

-- 5. INDEX
CREATE INDEX IF NOT EXISTS idx_sub_email  ON subscribers(email);
CREATE INDEX IF NOT EXISTS idx_wish_email ON wishlists(email);
