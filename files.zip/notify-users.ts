// ================================================================
// GAMEDEAL — SUPABASE EDGE FUNCTION
// Supabase Dashboard → Edge Functions → New Function → "notify-users"
// Bu kodu yapıştır ve Deploy et
// ================================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const RESEND_KEY  = Deno.env.get('RESEND_API_KEY')!
const SUPA_URL    = Deno.env.get('SUPABASE_URL')!
const SUPA_KEY    = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const SITE_URL    = Deno.env.get('SITE_URL') || 'https://gamedeal.app'
const FROM_EMAIL  = Deno.env.get('FROM_EMAIL') || 'bildirim@gamedeal.app'

const db = createClient(SUPA_URL, SUPA_KEY)

Deno.serve(async (req) => {
  // Sadece POST kabul et
  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 })
  }

  try {
    // 1. Epic'ten bu haftanın bedava oyunlarını çek
    const epicRes = await fetch(
      'https://store-site-backend-static.ak.epicgames.com/freeGamesPromotions?locale=tr&country=TR&allowCountries=TR'
    )
    const epicData = await epicRes.json()

    const freeGames = epicData?.data?.Catalog?.searchStore?.elements
      ?.filter((g: any) => {
        const promo = g?.promotions?.promotionalOffers
        return promo && promo.length > 0 &&
          promo[0]?.promotionalOffers?.[0]?.discountSetting?.discountPercentage === 0
      })
      ?.map((g: any) => ({
        title: g.title,
        url: `https://store.epicgames.com/tr/p/${g.productSlug || g.urlSlug}`,
        image: g.keyImages?.find((i: any) => i.type === 'OfferImageWide')?.url
      })) || []

    // Statik fallback (API değişirse)
    const games = freeGames.length > 0 ? freeGames : [
      { title: 'Arranger: A Role-Puzzling Adventure', url: 'https://store.epicgames.com' },
      { title: 'Trash Goblin', url: 'https://store.epicgames.com' }
    ]

    // 2. Bedava oyun isteyenleri al
    const { data: subs, error } = await db
      .from('subscribers')
      .select('email')
      .eq('notif_free', true)
      .eq('confirmed', true)

    if (error || !subs?.length) {
      return new Response(JSON.stringify({ message: 'Abone yok veya DB hatası', error }), { status: 200 })
    }

    // 3. E-posta gönder
    const gameListHTML = games.map(g =>
      `<li style="margin:8px 0">
        <a href="${g.url}" style="color:#00e5ff;font-weight:700;text-decoration:none">${g.title}</a>
       </li>`
    ).join('')

    let sent = 0
    for (const sub of subs) {
      const emailRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: `GameDeal <${FROM_EMAIL}>`,
          to: sub.email,
          subject: `🎮 Bu Hafta ${games.length} Oyun Bedava! Kaçırma!`,
          html: `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#080810;font-family:'Helvetica Neue',sans-serif">
  <div style="max-width:520px;margin:0 auto;padding:40px 24px">
    
    <div style="text-align:center;margin-bottom:32px">
      <h1 style="color:#00e5ff;font-size:32px;letter-spacing:4px;margin:0">GAMEDEAL</h1>
      <p style="color:#5a5a7a;font-size:12px;margin:4px 0 0">Haftalık Oyun Bildirimi</p>
    </div>

    <div style="background:#13131f;border:1px solid #232336;border-radius:14px;padding:28px;margin-bottom:20px">
      <h2 style="color:#e2e2f0;font-size:20px;margin:0 0 8px">
        🎁 Bu Hafta Bedava Oyunlar
      </h2>
      <p style="color:#5a5a7a;font-size:13px;margin:0 0 20px">
        Epic Games Store'dan hepsini ücretsiz al!
      </p>
      <ul style="list-style:none;padding:0;margin:0">
        ${gameListHTML}
      </ul>
    </div>

    <div style="text-align:center;margin-bottom:28px">
      <a href="${SITE_URL}" 
         style="display:inline-block;background:#00e5ff;color:#000;
                padding:14px 32px;border-radius:9px;text-decoration:none;
                font-weight:800;font-size:14px;letter-spacing:.5px">
        Tüm Fırsatları Gör →
      </a>
    </div>

    <div style="border-top:1px solid #232336;padding-top:20px;text-align:center">
      <p style="color:#3a3a5a;font-size:11px;margin:0">
        Bu e-postayı almak istemiyorsan 
        <a href="${SITE_URL}/unsubscribe?email=${encodeURIComponent(sub.email)}" 
           style="color:#5a5a7a">aboneliğini iptal et</a>
      </p>
    </div>
  </div>
</body>
</html>`
        })
      })

      if (emailRes.ok) {
        sent++
        // Log kaydet
        await db.from('notif_log').insert({
          email: sub.email,
          type: 'free_game',
          game_title: games.map(g => g.title).join(', ')
        })
      }
    }

    return new Response(
      JSON.stringify({ success: true, sent, games: games.map(g => g.title) }),
      { headers: { 'Content-Type': 'application/json' }, status: 200 }
    )

  } catch (err) {
    return new Response(
      JSON.stringify({ error: String(err) }),
      { headers: { 'Content-Type': 'application/json' }, status: 500 }
    )
  }
})

// ================================================================
// ZAMANLI ÇALIŞMA (Her Perşembe 15:00 UTC = 18:00 TR)
// Supabase Dashboard → Database → Scheduled Jobs → New Job:
//   Name:     weekly-notifier
//   Schedule: 0 15 * * 4
//   Function: notify-users
//   HTTP Method: POST
// ================================================================
